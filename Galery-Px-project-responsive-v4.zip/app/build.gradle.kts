plugins { id("com.android.application") }

android {
    namespace = "id.pixelsoft.pixelvault"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.pixelsoft.pixelvault"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0-test"
    }
}
