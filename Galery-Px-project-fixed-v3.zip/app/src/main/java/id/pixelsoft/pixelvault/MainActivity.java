package id.pixelsoft.pixelvault;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 101;
    private static final int REQ_EXPORT = 102;
    private static final int REQ_PERMISSION = 103;
    private static final int REQ_DELETE_MEDIA = 104;
    private static final String KEY_ALIAS = "pixelvault_aes_key_v1";
    private static final String PREFS = "pixelvault_prefs";
    private static final String PIN_HASH = "pin_hash";
    private static final String PIN_SALT = "pin_salt";
    private LinearLayout root;
    private String currentVaultFile;
    private boolean showHiddenApps = false;
    private boolean vaultUnlocked = false;
    private String calcEntry = "";
    private String pendingOperator = "";
    private Double pendingNumber = null;
    private String calcDisplay = "0";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showGallery();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14); b.setOnClickListener(v -> action.run());
        return b;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void startScreen(String title, String subtitle) {
        root = column(); root.setBackgroundColor(Color.rgb(246,248,248));
        LinearLayout header = column(); header.setPadding(dp(18),dp(16),dp(18),dp(14)); header.setBackgroundColor(Color.rgb(16,42,44));
        TextView h = text(title,23,Color.WHITE,true); h.setOnLongClickListener(v -> { showCalculator(); return true; });
        header.addView(h); TextView sub = text(subtitle,13,Color.rgb(197,220,220),false); header.addView(sub);
        root.addView(header);
        ScrollView scroll = new ScrollView(this); LinearLayout content = column(); content.setPadding(dp(14),dp(12),dp(14),dp(16)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = row(); nav.setPadding(dp(6),dp(5),dp(6),dp(5)); nav.setBackgroundColor(Color.WHITE);
        nav.addView(navButton("Galeri", this::showGallery),new LinearLayout.LayoutParams(0,dp(52),1));
        nav.addView(navButton("Aplikasi", this::showApps),new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(nav); setContentView(root); activeContent = content;
    }
    private void startGalleryScreen() {
        root = column();
        root.setBackgroundColor(Color.rgb(246,248,248));

        // A visually blank gesture strip is the private entry point.
        // Long-press it to open the calculator/PIN flow; no label or menu is shown.
        View hiddenEntry = new View(this);
        hiddenEntry.setBackgroundColor(Color.rgb(246,248,248));
        hiddenEntry.setOnLongClickListener(v -> { showCalculator(); return true; });
        root.addView(hiddenEntry, new LinearLayout.LayoutParams(-1, dp(30)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = column();
        content.setPadding(dp(3), dp(2), dp(3), dp(4));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        activeContent = content;
    }

    private LinearLayout activeContent;
    private Button navButton(String label, Runnable action) { Button b=button(label,action); b.setTextSize(12); return b; }
    private void section(LinearLayout host, String title, String body) {
        TextView t=text(title,18,Color.rgb(24,46,48),true); t.setPadding(0,dp(6),0,dp(4)); host.addView(t);
        if(body!=null&&!body.isEmpty()){TextView x=text(body,13,Color.rgb(87,103,105),false); x.setPadding(0,0,0,dp(8)); host.addView(x);}
    }
    private void showGallery() {
        startGalleryScreen();

        if (!hasMediaReadAccess()) {
            requestMediaReadAccess();
            return;
        }

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setUseDefaultMargins(true);
        activeContent.addView(grid);

        int count = 0;
        count += addMediaCollection(grid, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, 150);
        if (count < 150) {
            count += addMediaCollection(grid, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, 150 - count);
        }
        // Keep the home screen visually clean: no labels, empty-state menus, or action buttons.
    }

    private boolean hasMediaReadAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission("android.permission.READ_MEDIA_IMAGES") == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission("android.permission.READ_MEDIA_VIDEO") == PackageManager.PERMISSION_GRANTED;
        }
        return Build.VERSION.SDK_INT < 23
            || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaReadAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            java.util.ArrayList<String> needed = new java.util.ArrayList<>();
            if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES") != PackageManager.PERMISSION_GRANTED) needed.add("android.permission.READ_MEDIA_IMAGES");
            if (checkSelfPermission("android.permission.READ_MEDIA_VIDEO") != PackageManager.PERMISSION_GRANTED) needed.add("android.permission.READ_MEDIA_VIDEO");
            if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQ_PERMISSION);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMISSION);
        }
    }

    private int addMediaCollection(GridLayout grid, Uri collection, boolean video, int limit) {
        int count = 0;
        String[] projection = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.MIME_TYPE};
        try (Cursor c = getContentResolver().query(collection, projection, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c != null) {
                int idColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
                int mimeColumn = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE);
                while (c.moveToNext() && count < limit) {
                    long id = c.getLong(idColumn);
                    String mime = mimeColumn >= 0 ? c.getString(mimeColumn) : null;
                    Uri uri = Uri.withAppendedPath(collection, String.valueOf(id));
                    ImageView iv = new ImageView(this);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    iv.setBackground(bg(Color.LTGRAY, 8));
                    iv.setContentDescription(video ? "Video" : "Foto");
                    GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                    lp.width = 0;
                    lp.height = dp(116);
                    lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                    iv.setLayoutParams(lp);
                    try {
                        if (Build.VERSION.SDK_INT >= 29) {
                            android.graphics.Bitmap thumb = getContentResolver().loadThumbnail(uri, new android.util.Size(dp(220), dp(220)), null);
                            iv.setImageBitmap(thumb);
                        } else {
                            iv.setImageURI(uri);
                        }
                    } catch (Exception ignored) {
                        iv.setImageURI(uri);
                    }
                    int mediaType = video ? MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO : MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
                    iv.setOnClickListener(v -> openMedia(uri, mime, mediaType));
                    iv.setOnLongClickListener(v -> { showMediaActions(uri, mime, mediaType); return true; });
                    grid.addView(iv);
                    count++;
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat membaca " + (video ? "video" : "foto") + ". Periksa izin media.", Toast.LENGTH_SHORT).show();
        }
        return count;
    }

    private void openMedia(Uri uri, String mime, int type) {
        try {
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri, mime == null ? (type==MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO ? "video/*" : "image/*") : mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(view);
        } catch(Exception e) { showMediaActions(uri,mime,type); }
    }

    private void showMediaActions(Uri uri, String mime, int type) {
        String viewType = mime == null ? (type==MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO ? "video/*" : "image/*") : mime;
        new AlertDialog.Builder(this).setTitle(type==MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO?"Video":"Foto")
            .setItems(new String[]{"Buka","Bagikan","Hapus"},(dialog,which)->{
                if(which==0) openMedia(uri,mime,type);
                else if(which==1) {
                    Intent share=new Intent(Intent.ACTION_SEND); share.setType(viewType);
                    share.putExtra(Intent.EXTRA_STREAM,uri); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share,"Bagikan media"));
                } else confirmDeleteMedia(uri);
            }).show();
    }

    private void confirmDeleteMedia(Uri uri) {
        new AlertDialog.Builder(this).setTitle("Hapus media?")
            .setMessage("Media akan dihapus dari penyimpanan perangkat. Tindakan ini dapat memengaruhi aplikasi lain yang menggunakan file tersebut.")
            .setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->deleteMedia(uri)).show();
    }

    private void deleteMedia(Uri uri) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                android.app.PendingIntent request = MediaStore.createDeleteRequest(getContentResolver(), java.util.Collections.singletonList(uri));
                startIntentSenderForResult(request.getIntentSender(), REQ_DELETE_MEDIA, null, 0, 0, 0);
            } else {
                int deleted = getContentResolver().delete(uri,null,null);
                if(deleted>0) Toast.makeText(this,"Media dihapus.",Toast.LENGTH_SHORT).show();
                showGallery();
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 29 && e instanceof android.app.RecoverableSecurityException) {
                try { startIntentSenderForResult(((android.app.RecoverableSecurityException)e).getUserAction().getActionIntent().getIntentSender(), REQ_DELETE_MEDIA, null, 0, 0, 0); }
                catch(Exception ex) { Toast.makeText(this,"Android tidak mengizinkan penghapusan media ini.",Toast.LENGTH_LONG).show(); }
            } else Toast.makeText(this,"Android tidak mengizinkan penghapusan media ini.",Toast.LENGTH_LONG).show();
        } catch(Exception e) { Toast.makeText(this,"Gagal menghapus media.",Toast.LENGTH_SHORT).show(); }
    }

    private void pickMedia() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"}); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,REQ_IMPORT);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null)return;
        if(requestCode==REQ_DELETE_MEDIA) { showGallery(); return; }
        if(requestCode==REQ_IMPORT) {
            List<Uri> uris=new ArrayList<>(); if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());} else if(data.getData()!=null)uris.add(data.getData());
            int ok=0; for(Uri u:uris){try{encryptUri(u);ok++;}catch(Exception e){Toast.makeText(this,"Gagal mengenkripsi salah satu file: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
            Toast.makeText(this,"Berhasil mengenkripsi "+ok+" dari "+uris.size()+" file.",Toast.LENGTH_LONG).show(); vaultUnlocked=true; showVault();
        } else if(requestCode==REQ_EXPORT && currentVaultFile!=null) {
            try { decryptToUri(new File(getVaultDir(),currentVaultFile),data.getData()); Toast.makeText(this,"File berhasil dipulihkan ke lokasi yang dipilih.",Toast.LENGTH_LONG).show(); }
            catch(Exception e){Toast.makeText(this,"Pemulihan gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }
    private File getVaultDir(){File f=new File(getFilesDir(),"vault");if(!f.exists())f.mkdirs();return f;}
    private SecretKey getVaultKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(KEY_ALIAS))return (SecretKey)ks.getKey(KEY_ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec=new android.security.keystore.KeyGenParameterSpec.Builder(KEY_ALIAS,android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).setRandomizedEncryptionRequired(true).build();
        kg.init(spec);return kg.generateKey();
    }
    private void encryptUri(Uri uri) throws Exception {
        String id=UUID.randomUUID().toString()+".pv"; File dest=new File(getVaultDir(),id);
        try(InputStream raw=getContentResolver().openInputStream(uri); FileOutputStream fileOut=new FileOutputStream(dest)){
            if(raw==null)throw new Exception("File sumber tidak dapat dibuka");
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,getVaultKey());byte[] iv=cipher.getIV();fileOut.write(iv.length);fileOut.write(iv);
            try(CipherOutputStream encrypted=new CipherOutputStream(fileOut,cipher)){
                String name=queryDisplayName(uri);byte[] n=name.getBytes(StandardCharsets.UTF_8);encrypted.write(ByteBuffer.allocate(4).putInt(n.length).array());encrypted.write(n);
                byte[] buf=new byte[8192];int r;while((r=raw.read(buf))!=-1)encrypted.write(buf,0,r);
            }
        } catch(Exception e){dest.delete();throw e;}
    }
    private String queryDisplayName(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{"_display_name"},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "media";}
    private CipherInputStream decryptStream(File file) throws Exception {
        FileInputStream fin=new FileInputStream(file);int len=fin.read();if(len<12||len>32){fin.close();throw new Exception("Format brankas tidak dikenal");}byte[] iv=new byte[len];int got=fin.read(iv);if(got!=len){fin.close();throw new Exception("File rusak");}
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,getVaultKey(),new GCMParameterSpec(128,iv));return new CipherInputStream(fin,cipher);
    }
    private void decryptToUri(File encrypted,Uri target) throws Exception {
        try(CipherInputStream in=decryptStream(encrypted);OutputStream out=getContentResolver().openOutputStream(target,"w")){
            if(out==null)throw new Exception("Tujuan tidak dapat ditulis");byte[] lenb=readFully(in,4);int n=ByteBuffer.wrap(lenb).getInt();if(n<0||n>4096)throw new Exception("Metadata file tidak valid");readFully(in,n);
            byte[] buf=new byte[8192];int r;while((r=in.read(buf))!=-1)out.write(buf,0,r);
        }
    }
    private byte[] readFully(InputStream in,int n)throws Exception{byte[] b=new byte[n];int off=0;while(off<n){int r=in.read(b,off,n-off);if(r<0)throw new Exception("File tidak lengkap");off+=r;}return b;}
    private void showVault(){
        if(!hasPin()){new AlertDialog.Builder(this).setTitle("Brankas belum disetel").setMessage("Buka kalkulator rahasia dengan menekan lama judul Galeri, lalu masukkan PIN baru 4–8 digit dan tekan =.").setPositiveButton("Ke Galeri",(d,w)->showGallery()).show();return;}
        if(!vaultUnlocked){Toast.makeText(this,"Masukkan PIN melalui kalkulator rahasia.",Toast.LENGTH_SHORT).show();showCalculator();return;}
        startScreen("Brankas privat","Berkas disimpan terenkripsi di penyimpanan internal aplikasi");
        section(activeContent,"Media terenkripsi","Nama asli file tidak ditampilkan dalam daftar. Ekspor akan mendekripsi hanya ke lokasi yang kamu pilih.");
        activeContent.addView(button("＋  Tambahkan foto/video",this::pickMedia));
        File[] files=getVaultDir().listFiles((dir,name)->name.endsWith(".pv"));if(files==null)files=new File[0];Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        if(files.length==0)activeContent.addView(text("Brankas masih kosong.",14,Color.GRAY,false));
        for(int i=0;i<files.length;i++){
            File f=files[i];LinearLayout item=row();item.setPadding(dp(10),dp(7),dp(4),dp(7));item.setBackground(bg(Color.WHITE,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));item.setLayoutParams(lp);
            LinearLayout info=column();info.addView(text("Media terenkripsi "+(i+1),14,Color.rgb(30,50,50),true));info.addView(text(sizeLabel(f.length())+" · AES-GCM",11,Color.GRAY,false));item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button export=button("Pulihkan",()->startExport(f));item.addView(export);Button del=button("Hapus",()->new AlertDialog.Builder(this).setTitle("Hapus permanen?").setMessage("File terenkripsi ini akan dihapus dari brankas.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{if(f.delete())Toast.makeText(this,"File dihapus",Toast.LENGTH_SHORT).show();showVault();}).show());item.addView(del);activeContent.addView(item);
        }
        activeContent.addView(button("Kunci sekarang",()->{vaultUnlocked=false;showGallery();}));
    }
    private String sizeLabel(long n){if(n<1024)return n+" B";if(n<1048576)return (n/1024)+" KB";return String.format(java.util.Locale.US,"%.1f MB",n/1048576.0);}
    private void startExport(File f){currentVaultFile=f.getName();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"GaleryPx_media_"+System.currentTimeMillis()+".bin");startActivityForResult(i,REQ_EXPORT);}

    private boolean hasPin(){return getSharedPreferences(PREFS,MODE_PRIVATE).contains(PIN_HASH);}
    private byte[] makePinHash(String pin,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,160000,256);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}finally{spec.clearPassword();}}
    private void showCalculator(){calcEntry="";calcDisplay="0";pendingOperator="";pendingNumber=null;renderCalculator();}
    private void renderCalculator(){
        startScreen("Kalkulator","");
        TextView display=text(calcEntry.isEmpty()?calcDisplay:calcEntry,30,Color.rgb(18,40,42),true);display.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);display.setPadding(dp(12),dp(18),dp(12),dp(18));display.setBackground(bg(Color.WHITE,12));activeContent.addView(display);
        TextView info=text(hasPin()?"Masukkan PIN lalu tekan = untuk membuka brankas.":"Buat PIN 4–8 digit lalu tekan = untuk mengaktifkan brankas.",13,Color.GRAY,false);info.setPadding(0,dp(10),0,dp(12));activeContent.addView(info);
        String[][] keys={{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"C","0","⌫","="}};
        for(String[] line:keys){LinearLayout r=row();for(String k:line){Button b=button(k,()->onCalcKey(k));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));r.addView(b,p);}activeContent.addView(r);}
        activeContent.addView(button("Kembali ke galeri",this::showGallery));
    }
    private void onCalcKey(String k){
        if(k.equals("C")){calcEntry="";calcDisplay="0";pendingOperator="";pendingNumber=null;renderCalculator();return;}
        if(k.equals("⌫")){if(!calcEntry.isEmpty())calcEntry=calcEntry.substring(0,calcEntry.length()-1);calcDisplay=calcEntry.isEmpty()?"0":calcEntry;renderCalculator();return;}
        if(k.equals("=")){if(pendingOperator!=null&&!pendingOperator.isEmpty()&&pendingNumber!=null){try{double right=Double.parseDouble(calcEntry.isEmpty()?"0":calcEntry);double left=pendingNumber;double result;if(pendingOperator.equals("+"))result=left+right;else if(pendingOperator.equals("−"))result=left-right;else if(pendingOperator.equals("×"))result=left*right;else {if(right==0)throw new ArithmeticException("Pembagian dengan nol");result=left/right;}calcEntry="";calcDisplay=(result==(long)result)?String.valueOf((long)result):String.valueOf(result);pendingOperator="";pendingNumber=null;renderCalculator();return;}catch(Exception ex){Toast.makeText(this,"Operasi tidak valid.",Toast.LENGTH_SHORT).show();return;}}if(calcEntry.length()<4||calcEntry.length()>8){Toast.makeText(this,"PIN harus 4–8 digit, atau gunakan operasi aritmetika.",Toast.LENGTH_SHORT).show();return;}try{if(!hasPin()){byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);byte[] hash=makePinHash(calcEntry,salt);getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(PIN_SALT,android.util.Base64.encodeToString(salt,android.util.Base64.NO_WRAP)).putString(PIN_HASH,android.util.Base64.encodeToString(hash,android.util.Base64.NO_WRAP)).apply();vaultUnlocked=true;Toast.makeText(this,"PIN dibuat. Brankas siap digunakan.",Toast.LENGTH_LONG).show();showVault();}else{byte[] salt=android.util.Base64.decode(getSharedPreferences(PREFS,MODE_PRIVATE).getString(PIN_SALT,""),android.util.Base64.NO_WRAP);byte[] expected=android.util.Base64.decode(getSharedPreferences(PREFS,MODE_PRIVATE).getString(PIN_HASH,""),android.util.Base64.NO_WRAP);byte[] actual=makePinHash(calcEntry,salt);if(java.security.MessageDigest.isEqual(expected,actual)){vaultUnlocked=true;showVault();}else{calcEntry="";Toast.makeText(this,"PIN salah.",Toast.LENGTH_SHORT).show();renderCalculator();}}}catch(Exception e){Toast.makeText(this,"Kesalahan autentikasi.",Toast.LENGTH_SHORT).show();}return;}
        if(k.matches("[0-9]")){if(calcEntry.length()<8)calcEntry+=k;calcDisplay=calcEntry;renderCalculator();return;}
        if(k.equals("+")||k.equals("−")||k.equals("×")||k.equals("÷")){if(calcEntry.isEmpty()){Toast.makeText(this,"Masukkan angka terlebih dahulu.",Toast.LENGTH_SHORT).show();return;}try{pendingNumber=Double.parseDouble(calcEntry);pendingOperator=k.equals("÷")?"/":k; if(k.equals("÷"))pendingOperator="/";calcEntry="";calcDisplay="0";renderCalculator();}catch(Exception e){Toast.makeText(this,"Angka tidak valid.",Toast.LENGTH_SHORT).show();}return;}
    }

    private void showApps(){
        startScreen("Aplikasi privat","Uji Telegram, WhatsApp, dan Facebook");
        section(activeContent,"Target pengujian","Tombol Buka menjalankan aplikasi asli. Menyembunyikan dari daftar Galery Px hanya menyembunyikan pintasan di halaman ini; tidak menyembunyikan aplikasi dari Android atau menggandakannya.");
        activeContent.addView(button(showHiddenApps?"Sembunyikan aplikasi yang ditandai":"Tampilkan aplikasi yang disembunyikan",()->{showHiddenApps=!showHiddenApps;showApps();}));
        addSocialApp("Telegram","org.telegram.messenger");addSocialApp("WhatsApp","com.whatsapp");addSocialApp("Facebook","com.facebook.katana");
        section(activeContent,"Status kloning","Belum diimplementasikan pada build uji ini. Android tidak menyediakan API publik untuk menggandakan aplikasi pihak ketiga dengan isolasi data penuh. Mengklaim tombol ini sebagai kloning sungguhan akan menyesatkan.");
        activeContent.addView(button("Periksa aplikasi terpasang",()->new AlertDialog.Builder(this).setTitle("Pemeriksaan target").setMessage("Galery Px hanya dapat membuka aplikasi yang sudah terpasang. Mesin virtualisasi perlu proof of concept terpisah dan pengujian kompatibilitas untuk tiap aplikasi.").setPositiveButton("Mengerti",null).show()));
    }
    private void addSocialApp(String label,String pkg){
        boolean installed;try{getPackageManager().getPackageInfo(pkg,0);installed=true;}catch(Exception e){installed=false;}
        boolean hidden=getPreferences(MODE_PRIVATE).getBoolean("hidden_"+pkg,false);
        if(hidden&&!showHiddenApps)return;
        LinearLayout item=row();item.setPadding(dp(10),dp(8),dp(8),dp(8));item.setBackground(bg(Color.WHITE,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));item.setLayoutParams(lp);
        LinearLayout inf=column();inf.addView(text(label,15,Color.rgb(30,50,50),true));inf.addView(text(installed?"Terpasang · aplikasi asli":"Belum terdeteksi di perangkat",11,installed?Color.rgb(35,120,80):Color.GRAY,false));item.addView(inf,new LinearLayout.LayoutParams(0,-2,1));
        item.addView(button(installed?"Buka":"Info",()->{if(installed){Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null)startActivity(launch);else Toast.makeText(this,"Tidak ada launcher activity.",Toast.LENGTH_SHORT).show();}else new AlertDialog.Builder(this).setMessage("Pasang "+label+" dari sumber resmi terlebih dahulu.").setPositiveButton("OK",null).show();}));
        item.addView(button(hidden?"Tampilkan":"Sembunyikan",()->{getPreferences(MODE_PRIVATE).edit().putBoolean("hidden_"+pkg,!hidden).apply();showApps();}));activeContent.addView(item);
    }

    @Override public void onBackPressed(){vaultUnlocked=false;showGallery();}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSION) {
            boolean granted = false;
            if (grantResults != null) {
                for (int result : grantResults) {
                    if (result == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
                }
            }
            if (granted) showGallery();
            else Toast.makeText(this, "Izin media belum diberikan. Galeri perangkat tidak dapat dimuat.", Toast.LENGTH_LONG).show();
        }
    }
}
