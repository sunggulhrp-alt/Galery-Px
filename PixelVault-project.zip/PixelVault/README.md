# PixelVault — build uji 0.1.0

Proyek Android native sederhana untuk diuji pada Vivo V2111 / Android 12.

## Fitur pada build ini

- Layar awal berupa galeri media lokal.
- Menekan lama judul **Galeri** membuka kalkulator/PIN rahasia.
- PIN 4–8 digit; verifier dibuat menggunakan PBKDF2-HMAC-SHA256 dengan salt acak.
- Foto/video yang dipilih lewat Android document picker dienkripsi ke penyimpanan internal aplikasi menggunakan AES-256-GCM dan kunci Android Keystore.
- Daftar berkas brankas tidak menampilkan nama file asli.
- Pemulihan file dilakukan secara eksplisit melalui Android document picker.
- Halaman target Telegram, WhatsApp, Facebook dapat membuka aplikasi asli yang terpasang.
- Pintasan target dapat disembunyikan dari daftar di dalam PixelVault.

## Batasan yang disengaja dan harus diketahui

- Tombol **Sembunyikan** hanya menyembunyikan pintasan di daftar PixelVault. Itu tidak menyembunyikan aplikasi dari launcher Android, Pengaturan, atau aplikasi lain.
- Build ini **belum mengkloning** Telegram, WhatsApp, atau Facebook. Android tidak menyediakan API publik umum untuk menjalankan salinan aplikasi pihak ketiga dalam sandbox terpisah. Virtualisasi memerlukan proof of concept dan audit keamanan terpisah.
- Tombol operasi kalkulator di build uji menjalankan operasi aritmetika dasar; tombol `=` tanpa operasi digunakan untuk membuat atau memverifikasi PIN.
- Brankas menggunakan kunci Android Keystore. Menghapus data aplikasi atau menghapus aplikasi akan menghilangkan berkas brankas lokal; jangan simpan satu-satunya salinan file penting di sini.
- Tidak ada audit keamanan formal. Uji hanya dengan salinan foto/video yang tidak penting terlebih dahulu.
- Versi uji belum memiliki fitur pemulihan PIN, biometrik, backup, atau sinkronisasi.

## Build APK via GitHub Actions

1. Unggah isi folder proyek ini ke repositori GitHub baru atau repositori yang kamu kelola.
2. Buka tab **Actions**.
3. Pilih workflow **Build PixelVault APK** lalu **Run workflow**.
4. Setelah proses sukses, buka hasil run dan unduh artifact **PixelVault-debug-apk**.
5. Ekstrak ZIP artifact lalu instal `app-debug.apk` pada Vivo V2111. Izinkan instalasi dari sumber yang kamu gunakan hanya jika kamu percaya pada file yang dibangun sendiri.

## Build lokal

Memerlukan JDK 17, Android SDK platform 35 dan Gradle 8.9:

```bash
gradle assembleDebug
```

APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
